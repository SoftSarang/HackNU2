import React, {useState} from 'react';
import styled from 'styled-components';

const Page = styled.div`padding:100px 20px;max-width:900px;margin:0 auto;color:#fff;`;
const Form = styled.form`display:flex;flex-direction:column;gap:12px;`;
const Preview = styled.div`margin-top:18px;display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px;`;

export default function VirtualTour(){
  const [desc,setDesc]=useState('');
  const [files,setFiles]=useState([]);
  const [loading,setLoading]=useState(false);
  const [result,setResult]=useState(null);

  async function submit(e){
    e.preventDefault();
    setLoading(true);
    try{
      // Simple form data upload; backend should accept /api/virtual-tour
      const fd = new FormData();
      fd.append('description', desc);
      files.forEach(f=>fd.append('photos', f));

      const res = await fetch('/api/virtual-tour', { method: 'POST', body: fd, credentials: 'include' });
      if(!res.ok) throw new Error(await res.text());
      const body = await res.json();
      setResult(body);
    }catch(err){
      console.error(err);
      alert('Failed to create virtual tour: '+err.message);
    }finally{setLoading(false)}
  }

  function onFiles(e){
    setFiles(Array.from(e.target.files || []));
  }

  return (
    <Page>
      <h1>Virtual Tour Creator</h1>
      <p>Describe a property and optionally upload photos. We'll generate rooms and compile a tour video with voiceover.</p>
      <Form onSubmit={submit}>
        <label>Short description</label>
        <input value={desc} onChange={e=>setDesc(e.target.value)} placeholder="e.g. a modern 2BR apartment with large windows" />
        <label>Photos (optional)</label>
        <input type="file" multiple accept="image/*" onChange={onFiles} />
        <button type="submit" disabled={loading}>{loading? 'Creating...':'Create Virtual Tour'}</button>
      </Form>

      {result && (
        <div style={{marginTop:20}}>
          <h3>Result</h3>
          {result.preview_urls && (
            <Preview>
              {result.preview_urls.map((u,i)=> <img key={i} src={u} alt={`room-${i}`} style={{width:'100%',height:160,objectFit:'cover'}} />)}
            </Preview>
          )}
          {result.video_url && (
            <div style={{marginTop:12}}>
              <video src={result.video_url} controls style={{width:'100%'}} />
            </div>
          )}
        </div>
      )}
    </Page>
  )
}
