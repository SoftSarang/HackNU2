export { default } from './CanvasEraser';
