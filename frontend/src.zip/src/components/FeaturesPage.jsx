import React from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';

const Page = styled.div`padding-top:80px;min-height:100vh;color:#fff;`;
const Hero = styled.section`height:60vh;display:flex;align-items:center;justify-content:center;flex-direction:column;text-align:center;background:linear-gradient(180deg, rgba(0,0,0,0.6), rgba(0,0,0,0.6));`;
const Title = styled.h1`font-size:48px;margin:12px 0;`;
const TeamName = styled.h3`font-weight:400;color:#ddd;margin-top:6px;`;
const Func = styled.section`padding:40px 20px;max-width:1100px;margin:0 auto;`;
const Grid = styled.div`display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;`;
const Card = styled.div`background:#111;padding:18px;border-radius:12px;min-height:140px;display:flex;flex-direction:column;gap:8px;`;
const CTABtn = styled(Link)`margin-top:auto;background:#2a7cff;padding:8px 12px;border-radius:8px;color:#fff;text-decoration:none;text-align:center;display:inline-block;`;

export default function FeaturesPage(){
  return (
    <Page>
      <Hero>
        <Title>Team: EdgeMap</Title>
        <TeamName>AI + Creative — Team Dashboard</TeamName>
      </Hero>

      <Func>
        <h2>Tools</h2>
        <p>Choose a tool. Only "Virtual Tour" is functional for now; others are templates.</p>
        <Grid>
          <Card>
            <h3>Prompt Studio</h3>
            <p>Collaborative prompt library for teams (template).</p>
            <CTABtn to="/prompt-studio">Open</CTABtn>
          </Card>

          <Card>
            <h3>Image → Video</h3>
            <p>Template: convert images to short videos.</p>
            <CTABtn to="#">Open</CTABtn>
          </Card>

          <Card>
            <h3>Text → Video</h3>
            <p>Template: generate video from script (placeholder).</p>
            <CTABtn to="#">Open</CTABtn>
          </Card>

          <Card>
            <h3>VideoVault</h3>
            <p>Asset manager for team-generated media (placeholder).</p>
            <CTABtn to="/video-vault">Open</CTABtn>
          </Card>

          <Card>
            <h3>Virtual Tour (Working)</h3>
            <p>Generate a virtual tour from a short description and photos.</p>
            <CTABtn to="/virtual-tour">Open</CTABtn>
          </Card>
        </Grid>
      </Func>
    </Page>
  )
}
