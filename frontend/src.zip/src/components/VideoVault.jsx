import React from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';

const Page = styled.div`padding:100px 20px;max-width:1200px;margin:0 auto;color:#fff;`;
const Grid = styled.div`display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;`;
const Card = styled.div`background:#111;padding:12px;border-radius:10px;min-height:120px;`;

export default function VideoVault(){
  return (
    <Page>
      <h1>VideoVault (placeholder)</h1>
      <p>Asset manager for AI-generated content. History tab and grid will be added soon. Go to <Link to="/features">Features</Link>.</p>

      <h3>Sample assets</h3>
      <Grid>
        <Card>Image asset (placeholder)</Card>
        <Card>Video asset (placeholder)</Card>
        <Card>Image asset (placeholder)</Card>
      </Grid>
    </Page>
  )
}
