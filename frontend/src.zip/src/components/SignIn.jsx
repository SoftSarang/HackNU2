import React from "react";
import AuthPage from "./AuthPage";

export default function SignIn() {
  return <AuthPage mode="signin" />;
}
