import React from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';

const Page = styled.div`padding:100px 20px;max-width:1000px;margin:0 auto;color:#fff;`;

export default function PromptStudio(){
  return (
    <Page>
      <h1>PromptStudio (placeholder)</h1>
      <p>This page will host collaborative prompt editing and team prompts. For now it's a placeholder. Visit <Link to="/features">Features</Link>.</p>
    </Page>
  )
}
