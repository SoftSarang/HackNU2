import React from "react";
import AuthPage from "./AuthPage";

export default function SignUp() {
  return <AuthPage mode="signup" />;
}
