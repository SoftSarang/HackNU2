{
  "name"= "furrrow",
  "version"= "0.1.0",
  "private"= true,
  "author"="Aditya Yaduvanshi <https://adityayads.vercel.app>",
  "dependencies"= {
    "@babel/plugin-proposal-private-property-in-object": "^7.21.11",
    "@testing-library/jest-dom": "^5.16.5",
    "@testing-library/react": "^13.4.0",
    "@testing-library/user-event": "^13.5.0",
    "framer-motion": "^10.12.16",
    "prop-types": "^15.8.1",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-helmet": "^6.1.0",
    "react-intersection-observer": "^9.4.4",
    "react-router-dom": "^6.11.2",
    "react-scripts": "5.0.1",
    "styled-components": "^5.3.11",
    "styled-normalize": "^8.0.7",
    "web-vitals": "^2.1.4"
  },
  "scripts"= {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "eject": "react-scripts eject"
  },
  "eslintConfig"= {
    "extends": [
      "react-app",
      "react-app/jest"
    ]
  },
  "browserslist"= {
    "production" : [
      ">0.2%",
      "not dead",
      "not op_mini all"
    ],
    "development" : [
      "last 1 chrome version",
      "last 1 firefox version",
      "last 1 safari version"
    ]
  }
}