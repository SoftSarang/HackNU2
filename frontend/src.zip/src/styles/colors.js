export default {
  white: '#fff',
  black: '#000',
  red: '#c5fa50',
};
